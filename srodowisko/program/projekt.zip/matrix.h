#pragma once

#include <Eigen/Dense>

Eigen::VectorXd operate(const Eigen::MatrixXd& m, const Eigen::VectorXd& v);
